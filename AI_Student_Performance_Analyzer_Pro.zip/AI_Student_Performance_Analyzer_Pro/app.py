import io
from datetime import datetime

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeRegressor

st.set_page_config(
    page_title="Student Insight AI",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------- Styling ----------
st.markdown("""
<style>
.block-container {padding-top: 1.5rem; padding-bottom: 2rem; max-width: 1450px;}
.hero {padding: 1.35rem 1.5rem; border-radius: 18px; background: linear-gradient(115deg,#102a43,#176b87); color: white; margin-bottom: 1rem;}
.hero h1 {font-size: 2.35rem; margin: 0 0 .4rem 0;}
.hero p {font-size: 1.02rem; margin: 0; opacity: .92;}
.small-note {font-size: .88rem; opacity: .8;}
div[data-testid="stMetric"] {background: rgba(100,116,139,.10); padding: 14px 16px; border-radius: 12px; border: 1px solid rgba(100,116,139,.20);}
</style>
""", unsafe_allow_html=True)

REQUIRED_COLUMNS = [
    "student_id", "study_hours_per_week", "attendance_percent",
    "assignment_average", "previous_score", "final_score"
]
NUMERIC_FEATURES = [
    "study_hours_per_week", "attendance_percent",
    "assignment_average", "previous_score"
]
TARGET = "final_score"

def sample_data():
    # Synthetic example records only; not real student information.
    rows = [
        ("STU001", 3, 68, 65, 61, 63), ("STU002", 6, 82, 76, 73, 77),
        ("STU003", 8, 91, 88, 84, 89), ("STU004", 2, 59, 58, 55, 54),
        ("STU005", 5, 78, 74, 70, 73), ("STU006", 7, 86, 82, 80, 84),
        ("STU007", 4, 72, 69, 66, 68), ("STU008", 9, 95, 91, 90, 94),
        ("STU009", 1, 51, 48, 44, 46), ("STU010", 6, 88, 80, 77, 81),
        ("STU011", 3, 64, 62, 59, 60), ("STU012", 10, 97, 94, 92, 96),
        ("STU013", 5, 75, 72, 68, 72), ("STU014", 4, 70, 67, 63, 66),
        ("STU015", 8, 89, 85, 82, 87), ("STU016", 2, 57, 54, 50, 52),
        ("STU017", 7, 84, 81, 78, 82), ("STU018", 6, 80, 77, 74, 78),
        ("STU019", 3, 66, 64, 60, 62), ("STU020", 9, 93, 90, 88, 92),
        ("STU021", 4, 73, 70, 67, 69), ("STU022", 5, 79, 75, 72, 76),
        ("STU023", 1, 49, 45, 42, 44), ("STU024", 8, 90, 87, 83, 88),
        ("STU025", 6, 83, 79, 76, 80), ("STU026", 2, 61, 57, 53, 56),
        ("STU027", 7, 87, 83, 79, 85), ("STU028", 5, 76, 73, 69, 74),
        ("STU029", 4, 69, 66, 62, 65), ("STU030", 10, 98, 95, 94, 97),
        ("STU031", 3, 63, 60, 56, 59), ("STU032", 7, 85, 82, 78, 83),
    ]
    return pd.DataFrame(rows, columns=REQUIRED_COLUMNS)

def prepare_data(df):
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        return None, missing
    df = df[REQUIRED_COLUMNS].copy()
    df["student_id"] = df["student_id"].astype(str).str.strip()
    for col in NUMERIC_FEATURES + [TARGET]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["student_id", TARGET])
    df = df[df["student_id"].ne("")]
    df = df.drop_duplicates(subset=["student_id"], keep="last")
    # Bound obviously invalid values rather than silently accepting them.
    df = df[
        df["study_hours_per_week"].between(0, 168, inclusive="both")
        & df["attendance_percent"].between(0, 100, inclusive="both")
        & df["assignment_average"].between(0, 100, inclusive="both")
        & df["previous_score"].between(0, 100, inclusive="both")
        & df["final_score"].between(0, 100, inclusive="both")
    ]
    return df.reset_index(drop=True), []

def make_model(model_name):
    if model_name == "Linear Regression":
        estimator = LinearRegression()
    elif model_name == "Decision Tree":
        estimator = DecisionTreeRegressor(max_depth=4, random_state=42)
    else:
        estimator = RandomForestRegressor(n_estimators=150, max_depth=6, random_state=42)
    preprocessor = ColumnTransformer([
        ("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]), NUMERIC_FEATURES)
    ])
    return Pipeline([("preprocessor", preprocessor), ("model", estimator)])

def make_csv_download(frame):
    return frame.to_csv(index=False).encode("utf-8-sig")

# ---------- Header ----------
st.markdown("""
<div class="hero">
  <h1>🎓 Student Insight AI</h1>
  <p>Student performance analytics · Data quality checks · Machine learning experiments · Prediction sandbox</p>
</div>
""", unsafe_allow_html=True)

st.info(
    "Learning/portfolio demo only. The bundled dataset is synthetic. Predictions are estimates, "
    "not facts about a student's ability. Do not use this app for admissions, grading, discipline, "
    "or other high-stakes decisions."
)

# ---------- Sidebar / data ----------
with st.sidebar:
    st.header("📁 Data source")
    uploaded = st.file_uploader("Upload student CSV", type=["csv"], help="CSV must contain the six required columns shown below.")
    st.caption("If no file is uploaded, the app uses synthetic demo records.")
    with st.expander("Required CSV columns", expanded=True):
        for col in REQUIRED_COLUMNS:
            st.code(col, language=None)
    st.divider()
    st.header("🎛️ Filters")
    st.caption("Filters affect the dashboard and table. Model training uses the filtered rows.")

if uploaded is not None:
    try:
        raw_df = pd.read_csv(uploaded)
        source_label = f"Uploaded file: {uploaded.name}"
    except Exception as exc:
        st.error(f"CSV read nahi ho saki: {exc}")
        st.stop()
else:
    raw_df = sample_data()
    source_label = "Built-in synthetic demo data"

df, missing_columns = prepare_data(raw_df)
if missing_columns:
    st.error("CSV mein required columns missing hain: " + ", ".join(missing_columns))
    st.write("Required columns:", REQUIRED_COLUMNS)
    st.stop()

if df.empty:
    st.error("Valid records nahi milay. Numeric values aur ranges check karein.")
    st.stop()

with st.sidebar:
    min_att, max_att = st.slider(
        "Attendance range (%)", min_value=0, max_value=100,
        value=(0, 100), step=5
    )
    min_score, max_score = st.slider(
        "Final score range", min_value=0, max_value=100,
        value=(0, 100), step=5
    )
    filtered = df[
        df["attendance_percent"].between(min_att, max_att)
        & df["final_score"].between(min_score, max_score)
    ].copy()
    st.caption(f"{len(filtered)} of {len(df)} valid records match filters.")

if filtered.empty:
    st.warning("In filters ke liye koi record nahi. Sidebar filters widen karein.")
    st.stop()

# ---------- Summary cards ----------
avg_score = filtered[TARGET].mean()
avg_att = filtered["attendance_percent"].mean()
avg_study = filtered["study_hours_per_week"].mean()
pass_rate = (filtered[TARGET] >= 50).mean() * 100
c1, c2, c3, c4 = st.columns(4)
c1.metric("Students / records", f"{len(filtered)}")
c2.metric("Average final score", f"{avg_score:.1f}/100")
c3.metric("Average attendance", f"{avg_att:.1f}%")
c4.metric("Score ≥ 50", f"{pass_rate:.1f}%")
st.caption(f"Data source: {source_label} · Valid rows after cleaning: {len(df)}")

tabs = st.tabs(["📊 Overview", "🔎 Explore Data", "🧹 Data Quality", "🧠 Train Models", "🎯 Try Prediction", "📋 Data Table"])

# ---------- Overview ----------
with tabs[0]:
    left, right = st.columns(2)
    with left:
        st.subheader("Final score distribution")
        fig, ax = plt.subplots()
        ax.hist(filtered[TARGET], bins=10, edgecolor="black")
        ax.set_xlabel("Final score")
        ax.set_ylabel("Number of students")
        ax.set_title("Score distribution")
        st.pyplot(fig, clear_figure=True)
        plt.close(fig)
    with right:
        st.subheader("Study hours vs final score")
        fig, ax = plt.subplots()
        ax.scatter(filtered["study_hours_per_week"], filtered[TARGET], alpha=0.8)
        ax.set_xlabel("Study hours per week")
        ax.set_ylabel("Final score")
        ax.set_title("Study time and scores")
        st.pyplot(fig, clear_figure=True)
        plt.close(fig)
    st.subheader("Quick insights")
    most_att = filtered.loc[filtered["attendance_percent"].idxmax()]
    st.write(f"- Highest attendance in the filtered data: **{most_att['attendance_percent']:.0f}%**.")
    st.write(f"- Average study time: **{avg_study:.1f} hours/week**.")
    st.write(f"- Records with score below 50: **{int((filtered[TARGET] < 50).sum())}**.")
    st.caption("These are descriptive patterns in the supplied dataset, not proof that one factor causes another.")

# ---------- Explore data ----------
with tabs[1]:
    st.subheader("Explore relationships")
    chosen_x = st.selectbox("Choose a feature", NUMERIC_FEATURES, index=0)
    fig, ax = plt.subplots()
    ax.scatter(filtered[chosen_x], filtered[TARGET], alpha=0.8)
    ax.set_xlabel(chosen_x.replace("_", " ").title())
    ax.set_ylabel("Final score")
    ax.set_title(f"{chosen_x.replace('_', ' ').title()} vs final score")
    st.pyplot(fig, clear_figure=True)
    plt.close(fig)
    st.subheader("Correlation matrix")
    corr = filtered[NUMERIC_FEATURES + [TARGET]].corr(numeric_only=True)
    fig, ax = plt.subplots()
    im = ax.imshow(corr, aspect="auto", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr.columns)), corr.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(corr.index)), corr.index)
    fig.colorbar(im, ax=ax, label="Correlation")
    fig.tight_layout()
    st.pyplot(fig, clear_figure=True)
    plt.close(fig)
    st.dataframe(corr.round(2), use_container_width=True)

# ---------- Data quality ----------
with tabs[2]:
    st.subheader("Data quality report")
    original = raw_df.copy()
    normalized_cols = [str(c).strip().lower() for c in original.columns]
    st.write(f"**Rows in source file:** {len(original)}")
    st.write(f"**Valid rows after cleaning:** {len(df)}")
    st.write(f"**Rows removed by cleaning/deduplication:** {max(0, len(original) - len(df))}")
    missing_summary = df.isna().sum().rename("Missing values").to_frame()
    st.dataframe(missing_summary, use_container_width=True)
    st.markdown("**Validation rules used**")
    st.markdown("""
    - Student ID must not be blank.
    - Numeric fields are converted to numbers; invalid values are treated as missing.
    - A record must have a valid `final_score`.
    - Duplicate student IDs are reduced to one record (last occurrence kept).
    - Study hours must be 0–168; attendance and scores must be 0–100.
    """)
    st.download_button("⬇️ Download cleaned CSV", data=make_csv_download(df),
                       file_name="cleaned_student_data.csv", mime="text/csv")

# ---------- Model training ----------
with tabs[3]:
    st.subheader("Train and compare regression models")
    st.write("Model target: `final_score`. Features: study hours, attendance, assignment average, and previous score.")
    model_name = st.selectbox("Choose model", ["Random Forest", "Linear Regression", "Decision Tree"])
    test_size = st.slider("Test data (%)", 20, 40, 25, 5)
    if len(filtered) < 8:
        st.warning("Reliable demo evaluation ke liye kam az kam 8 valid records rakhne ki koshish karein.")
    if st.button("🚀 Train selected model", type="primary"):
        if len(filtered) < 5:
            st.error("Model training ke liye kam records hain. Zyada valid rows upload karein.")
        else:
            X = filtered[NUMERIC_FEATURES]
            y = filtered[TARGET]
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size / 100, random_state=42
            )
            model = make_model(model_name)
            model.fit(X_train, y_train)
            preds = model.predict(X_test)
            mae = mean_absolute_error(y_test, preds)
            rmse = mean_squared_error(y_test, preds) ** 0.5
            r2 = r2_score(y_test, preds) if len(y_test) >= 2 else float("nan")
            st.session_state["trained_model"] = model
            st.session_state["trained_model_name"] = model_name
            st.session_state["model_features"] = NUMERIC_FEATURES
            st.session_state["model_results"] = pd.DataFrame({
                "Actual score": y_test.to_numpy(),
                "Predicted score": preds.round(1),
                "Absolute error": (y_test.to_numpy() - preds).astype(float).__abs__().round(1),
            }, index=y_test.index).sort_index()
            m1, m2, m3 = st.columns(3)
            m1.metric("MAE (lower is better)", f"{mae:.2f}")
            m2.metric("RMSE (lower is better)", f"{rmse:.2f}")
            m3.metric("R² score", f"{r2:.3f}" if pd.notna(r2) else "N/A")
            st.success(f"{model_name} trained. Prediction tab mein model use kar sakte hain.")
            st.caption("Small synthetic datasets par scores unstable ho sakte hain; ye learning metrics hain, job-grade evidence nahi.")
            st.subheader("Actual vs predicted on test split")
            st.dataframe(st.session_state["model_results"], use_container_width=True)
            fig, ax = plt.subplots()
            result = st.session_state["model_results"]
            ax.scatter(result["Actual score"], result["Predicted score"])
            ax.plot([0, 100], [0, 100], linestyle="--")
            ax.set_xlim(0, 100); ax.set_ylim(0, 100)
            ax.set_xlabel("Actual score"); ax.set_ylabel("Predicted score")
            ax.set_title("Actual vs predicted")
            st.pyplot(fig, clear_figure=True)
            plt.close(fig)
    if "model_results" in st.session_state:
        st.download_button(
            "⬇️ Download model test results",
            data=make_csv_download(st.session_state["model_results"]),
            file_name="model_test_results.csv",
            mime="text/csv"
        )

# ---------- Prediction ----------
with tabs[4]:
    st.subheader("Predict an estimated score")
    st.caption("Use this as a learning sandbox only. It must not be used to label or judge a real student.")
    with st.form("prediction_form"):
        p1, p2 = st.columns(2)
        with p1:
            study_hours = st.number_input("Study hours per week", min_value=0.0, max_value=168.0, value=6.0, step=0.5)
            attendance = st.number_input("Attendance (%)", min_value=0.0, max_value=100.0, value=80.0, step=1.0)
        with p2:
            assignment = st.number_input("Assignment average (0–100)", min_value=0.0, max_value=100.0, value=75.0, step=1.0)
            previous = st.number_input("Previous score (0–100)", min_value=0.0, max_value=100.0, value=70.0, step=1.0)
        submit_prediction = st.form_submit_button("Estimate score", type="primary")
    if submit_prediction:
        if "trained_model" not in st.session_state:
            st.warning("Pehle 'Train Models' tab mein model train karein. Phir yahan estimate karein.")
        else:
            input_df = pd.DataFrame([{
                "study_hours_per_week": study_hours,
                "attendance_percent": attendance,
                "assignment_average": assignment,
                "previous_score": previous,
            }])
            estimate = float(st.session_state["trained_model"].predict(input_df)[0])
            estimate = max(0.0, min(100.0, estimate))
            st.metric("Estimated final score", f"{estimate:.1f}/100")
            st.caption(f"Model used: {st.session_state.get('trained_model_name', 'Unknown')}. Estimate can be inaccurate.")
            pred_row = input_df.copy()
            pred_row["estimated_final_score"] = round(estimate, 1)
            pred_row["model"] = st.session_state.get("trained_model_name", "Unknown")
            pred_row["created_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            st.download_button("⬇️ Download this prediction", data=make_csv_download(pred_row),
                               file_name="student_score_estimate.csv", mime="text/csv")

# ---------- Data table ----------
with tabs[5]:
    st.subheader("Cleaned dataset")
    search = st.text_input("Search student ID", placeholder="e.g. STU012")
    table_df = filtered.copy()
    if search.strip():
        table_df = table_df[table_df["student_id"].str.contains(search.strip(), case=False, na=False)]
    st.dataframe(table_df, use_container_width=True, hide_index=True)
    st.download_button("⬇️ Download visible table as CSV", data=make_csv_download(table_df),
                       file_name="student_data_export.csv", mime="text/csv")
    st.caption("Only synthetic or appropriately anonymized data should be used for portfolio demos.")
