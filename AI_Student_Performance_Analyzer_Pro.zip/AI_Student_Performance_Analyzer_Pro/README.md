# Student Insight AI — Student Performance Analyzer

A beginner-friendly portfolio project built with Python, Streamlit, Pandas, Matplotlib, and scikit-learn.

## Features
- Overview dashboard with summary metrics.
- CSV upload and required-column validation.
- Data cleaning, duplicate handling, and range checks.
- Filters for attendance and final score.
- Charts: score distribution, study-hours relationship, and correlation matrix.
- Train and evaluate Linear Regression, Decision Tree, and Random Forest regressors.
- Evaluation metrics: MAE, RMSE, and R².
- Prediction sandbox after training a model.
- Download cleaned data, visible table, test predictions, and a single prediction as CSV.
- Synthetic sample data included.

## Requirements
- Windows 10/11
- Python 3.10 or newer recommended
- Internet for installing packages

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `AI_Student_Performance_Analyzer_Pro` folder.
3. Click the File Explorer address bar, type `cmd`, and press Enter.
4. Run these commands one at a time:

```cmd
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

If `py` is not recognized, try `python --version`. If no Python version appears, install Python from https://www.python.org/downloads/ and enable “Add Python to PATH” during setup.

The browser normally opens at `http://localhost:8501`.

## CSV format
Your CSV must contain these exact columns:

- `student_id`
- `study_hours_per_week`
- `attendance_percent`
- `assignment_average`
- `previous_score`
- `final_score`

Example row:

```csv
STU100,6,82,75,70,78
```

Numeric values must be within sensible ranges: study hours 0–168; attendance and score fields 0–100.

## Beginner learning checklist
1. Run the app and explore the tabs.
2. Open `app.py` and find `sample_data()`.
3. Change one demo row and see how charts change.
4. Train each of the three models and compare MAE/RMSE/R².
5. Upload a small CSV you created yourself with fake/demo data.
6. Add a new chart or a new filter.
7. Push the project to GitHub with screenshots and a clear README.

## Portfolio description
**Student Insight AI — Machine Learning Dashboard**  
Built an interactive student-performance analytics dashboard using Python, Streamlit, Pandas, Matplotlib, and scikit-learn. Implemented CSV validation and cleaning, exploratory data analysis, regression-model training and evaluation, score estimation, and downloadable reports.

## Important responsible-use note
The sample data is synthetic. Model estimates can be wrong and depend on the quality and size of the data. This educational app must not be used for admissions, grading, discipline, or other high-stakes decisions. Never upload identifiable student records to a public demo.
